--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "AdventureWorks";
--
-- Name: AdventureWorks; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "AdventureWorks" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE "AdventureWorks" OWNER TO postgres;

\connect "AdventureWorks"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: dateadd_day(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_day(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 day')::date
$_$;


ALTER FUNCTION public.dateadd_day(integer, date) OWNER TO postgres;

--
-- Name: dateadd_day(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_day(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 day')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_day(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_day(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_day(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 day')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_day(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_hour(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_hour(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 hour')::date
$_$;


ALTER FUNCTION public.dateadd_hour(integer, date) OWNER TO postgres;

--
-- Name: dateadd_hour(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_hour(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 hour')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_hour(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_hour(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_hour(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 hour')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_hour(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_minute(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_minute(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 minute')::date
$_$;


ALTER FUNCTION public.dateadd_minute(integer, date) OWNER TO postgres;

--
-- Name: dateadd_minute(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_minute(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 minute')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_minute(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_minute(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_minute(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 minute')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_minute(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_month(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_month(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 month')::date
$_$;


ALTER FUNCTION public.dateadd_month(integer, date) OWNER TO postgres;

--
-- Name: dateadd_month(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_month(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 month')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_month(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_month(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_month(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 month')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_month(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_quarter(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_quarter(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * 3 * interval '1 month')::date
$_$;


ALTER FUNCTION public.dateadd_quarter(integer, date) OWNER TO postgres;

--
-- Name: dateadd_quarter(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_quarter(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * 3 * interval '1 month')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_quarter(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_quarter(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_quarter(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * 3 * interval '1 month')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_quarter(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_second(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_second(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 second')::date
$_$;


ALTER FUNCTION public.dateadd_second(integer, date) OWNER TO postgres;

--
-- Name: dateadd_second(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_second(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 second')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_second(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_second(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_second(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 second')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_second(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_week(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_week(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 week')::date
$_$;


ALTER FUNCTION public.dateadd_week(integer, date) OWNER TO postgres;

--
-- Name: dateadd_week(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_week(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 week')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_week(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_week(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_week(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 week')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_week(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: dateadd_year(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_year(integer, date) RETURNS date
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 year')::date
$_$;


ALTER FUNCTION public.dateadd_year(integer, date) OWNER TO postgres;

--
-- Name: dateadd_year(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_year(integer, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 year')::timestamp without time zone
$_$;


ALTER FUNCTION public.dateadd_year(integer, timestamp without time zone) OWNER TO postgres;

--
-- Name: dateadd_year(integer, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dateadd_year(integer, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE sql
    AS $_$
SELECT ($2 + $1 * interval '1 year')::timestamp with time zone
$_$;


ALTER FUNCTION public.dateadd_year(integer, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT $1 - $2
$_$;


ALTER FUNCTION public.datediff(date, date) OWNER TO postgres;

--
-- Name: datediff_day(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_day(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT ($2 - $1)::int
$_$;


ALTER FUNCTION public.datediff_day(date, date) OWNER TO postgres;

--
-- Name: datediff_day(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_day(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT date_part('day',$2 - $1)::int
$_$;


ALTER FUNCTION public.datediff_day(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_day(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_day(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT date_part('day',$2 - $1)::int
$_$;


ALTER FUNCTION public.datediff_day(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_hour(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_hour(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_day($1, $2) * 24 + date_part('hour', $2::timestamp - $1::timestamp))::int
$_$;


ALTER FUNCTION public.datediff_hour(date, date) OWNER TO postgres;

--
-- Name: datediff_hour(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_hour(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_day($1, $2) * 24 + date_part('hour', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_hour(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_hour(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_hour(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_day($1, $2) * 24 + date_part('hour', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_hour(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_minute(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_minute(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_hour($1, $2) * 60 + date_part('minute', $2::timestamp - $1::timestamp))::int
$_$;


ALTER FUNCTION public.datediff_minute(date, date) OWNER TO postgres;

--
-- Name: datediff_minute(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_minute(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_hour($1, $2) * 60 + date_part('minute', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_minute(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_minute(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_minute(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_hour($1, $2) * 60 + date_part('minute', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_minute(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_month(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_month(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (12 * datediff_year($1,$2) + date_part('month',$2) - date_part('month',$1))::int
$_$;


ALTER FUNCTION public.datediff_month(date, date) OWNER TO postgres;

--
-- Name: datediff_month(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_month(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (12 * datediff_year($1,$2) + date_part('month',$2) - date_part('month',$1))::int
$_$;


ALTER FUNCTION public.datediff_month(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_month(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_month(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (12 * datediff_year($1,$2) + date_part('month',$2) - date_part('month',$1))::int
$_$;


ALTER FUNCTION public.datediff_month(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_second(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_second(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_minute($1, $2) * 60 + date_part('second', $2::timestamp - $1::timestamp))::int
$_$;


ALTER FUNCTION public.datediff_second(date, date) OWNER TO postgres;

--
-- Name: datediff_second(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_second(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_minute($1, $2) * 60 + date_part('second', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_second(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_second(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_second(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (datediff_minute($1, $2) * 60 + date_part('second', $2 - $1))::int
$_$;


ALTER FUNCTION public.datediff_second(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_week(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_week(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT TRUNC(datediff_day($1, $2)/7)::int
$_$;


ALTER FUNCTION public.datediff_week(date, date) OWNER TO postgres;

--
-- Name: datediff_week(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_week(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT TRUNC(datediff_day($1, $2)/7)::int
$_$;


ALTER FUNCTION public.datediff_week(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_week(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_week(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT TRUNC(datediff_day($1, $2)/7)::int
$_$;


ALTER FUNCTION public.datediff_week(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: datediff_year(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_year(date, date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$2) - date_part('year',$1))::int
$_$;


ALTER FUNCTION public.datediff_year(date, date) OWNER TO postgres;

--
-- Name: datediff_year(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_year(timestamp without time zone, timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$2) - date_part('year',$1))::int
$_$;


ALTER FUNCTION public.datediff_year(timestamp without time zone, timestamp without time zone) OWNER TO postgres;

--
-- Name: datediff_year(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.datediff_year(timestamp with time zone, timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$2) - date_part('year',$1))::int
$_$;


ALTER FUNCTION public.datediff_year(timestamp with time zone, timestamp with time zone) OWNER TO postgres;

--
-- Name: day(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.day(date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('day',$1))::int
$_$;


ALTER FUNCTION public.day(date) OWNER TO postgres;

--
-- Name: day(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.day(timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('day',$1))::int
$_$;


ALTER FUNCTION public.day(timestamp without time zone) OWNER TO postgres;

--
-- Name: day(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.day(timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('day',$1))::int
$_$;


ALTER FUNCTION public.day(timestamp with time zone) OWNER TO postgres;

--
-- Name: month(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.month(date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('month',$1))::int
$_$;


ALTER FUNCTION public.month(date) OWNER TO postgres;

--
-- Name: month(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.month(timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('month',$1))::int
$_$;


ALTER FUNCTION public.month(timestamp without time zone) OWNER TO postgres;

--
-- Name: month(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.month(timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('month',$1))::int
$_$;


ALTER FUNCTION public.month(timestamp with time zone) OWNER TO postgres;

--
-- Name: year(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.year(date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$1))::int
$_$;


ALTER FUNCTION public.year(date) OWNER TO postgres;

--
-- Name: year(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.year(timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$1))::int
$_$;


ALTER FUNCTION public.year(timestamp without time zone) OWNER TO postgres;

--
-- Name: year(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.year(timestamp with time zone) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (date_part('year',$1))::int
$_$;


ALTER FUNCTION public.year(timestamp with time zone) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    addressid integer NOT NULL,
    addressline1 character varying(60) NOT NULL,
    addressline2 character varying(60),
    city character varying(30) NOT NULL,
    stateprovince character varying(50) NOT NULL,
    countryregion character varying(50) NOT NULL,
    postalcode character varying(15) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_addressid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_addressid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_addressid_seq OWNER TO postgres;

--
-- Name: address_addressid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_addressid_seq OWNED BY public.address.addressid;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customerid integer NOT NULL,
    namestyle boolean DEFAULT false NOT NULL,
    title character varying(8),
    firstname character varying(50) NOT NULL,
    middlename character varying(50),
    lastname character varying(50) NOT NULL,
    suffix character varying(10),
    companyname character varying(128),
    salesperson character varying(256),
    emailaddress character varying(50),
    phone character varying(25),
    passwordhash character varying(128) NOT NULL,
    passwordsalt character varying(10) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customerid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_customerid_seq OWNER TO postgres;

--
-- Name: customer_customerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customerid_seq OWNED BY public.customer.customerid;


--
-- Name: customeraddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customeraddress (
    customerid integer NOT NULL,
    addressid integer NOT NULL,
    addresstype character varying(50) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.customeraddress OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    productid integer NOT NULL,
    name character varying(50) NOT NULL,
    productnumber character varying(25) NOT NULL,
    color character varying(15),
    standardcost numeric(19,4) NOT NULL,
    listprice numeric(19,4) NOT NULL,
    size character varying(5),
    weight numeric(10,2),
    productcategoryid integer,
    productmodelid integer,
    sellstartdate timestamp(3) without time zone NOT NULL,
    sellenddate timestamp(3) without time zone,
    discontinueddate timestamp(3) without time zone,
    thumbnailphoto bytea,
    thumbnailphotofilename character varying(50),
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_productid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_productid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productid_seq OWNER TO postgres;

--
-- Name: product_productid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_productid_seq OWNED BY public.product.productid;


--
-- Name: productcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productcategory (
    productcategoryid integer NOT NULL,
    parentproductcategoryid integer,
    name character varying(50) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.productcategory OWNER TO postgres;

--
-- Name: productcategory_productcategoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productcategory_productcategoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productcategory_productcategoryid_seq OWNER TO postgres;

--
-- Name: productcategory_productcategoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productcategory_productcategoryid_seq OWNED BY public.productcategory.productcategoryid;


--
-- Name: productdescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productdescription (
    productdescriptionid integer NOT NULL,
    description character varying(400) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.productdescription OWNER TO postgres;

--
-- Name: productdescription_productdescriptionid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productdescription_productdescriptionid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productdescription_productdescriptionid_seq OWNER TO postgres;

--
-- Name: productdescription_productdescriptionid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productdescription_productdescriptionid_seq OWNED BY public.productdescription.productdescriptionid;


--
-- Name: productmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productmodel (
    productmodelid integer NOT NULL,
    name character varying(50) NOT NULL,
    catalogdescription text,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.productmodel OWNER TO postgres;

--
-- Name: productmodel_productmodelid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productmodel_productmodelid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productmodel_productmodelid_seq OWNER TO postgres;

--
-- Name: productmodel_productmodelid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productmodel_productmodelid_seq OWNED BY public.productmodel.productmodelid;


--
-- Name: productmodelproductdescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productmodelproductdescription (
    productmodelid integer NOT NULL,
    productdescriptionid integer NOT NULL,
    culture character varying(6) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.productmodelproductdescription OWNER TO postgres;

--
-- Name: salesorderdetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salesorderdetail (
    salesorderid integer NOT NULL,
    salesorderdetailid integer NOT NULL,
    orderqty smallint NOT NULL,
    productid integer NOT NULL,
    unitprice numeric(19,4) NOT NULL,
    unitpricediscount numeric(19,4) DEFAULT 0 NOT NULL,
    linetotal numeric(40,6) NOT NULL,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.salesorderdetail OWNER TO postgres;

--
-- Name: salesorderdetail_salesorderdetailid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salesorderdetail_salesorderdetailid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.salesorderdetail_salesorderdetailid_seq OWNER TO postgres;

--
-- Name: salesorderdetail_salesorderdetailid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salesorderdetail_salesorderdetailid_seq OWNED BY public.salesorderdetail.salesorderdetailid;


--
-- Name: salesorderheader; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salesorderheader (
    salesorderid integer NOT NULL,
    revisionnumber smallint DEFAULT 0 NOT NULL,
    orderdate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    duedate timestamp(3) without time zone NOT NULL,
    shipdate timestamp(3) without time zone,
    status smallint DEFAULT 1 NOT NULL,
    onlineorderflag boolean DEFAULT true NOT NULL,
    salesordernumber character varying(25) NOT NULL,
    purchaseordernumber character varying(25),
    accountnumber character varying(15),
    customerid integer NOT NULL,
    shiptoaddressid integer,
    billtoaddressid integer,
    shipmethod character varying(50) NOT NULL,
    creditcardapprovalcode character varying(15),
    subtotal numeric(19,4) DEFAULT 0 NOT NULL,
    taxamt numeric(19,4) DEFAULT 0 NOT NULL,
    freight numeric(19,4) DEFAULT 0 NOT NULL,
    totaldue numeric(19,4) NOT NULL,
    comment text,
    rowguid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    modifieddate timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.salesorderheader OWNER TO postgres;

--
-- Name: salesorderheader_salesorderid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salesorderheader_salesorderid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.salesorderheader_salesorderid_seq OWNER TO postgres;

--
-- Name: salesorderheader_salesorderid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salesorderheader_salesorderid_seq OWNED BY public.salesorderheader.salesorderid;


--
-- Name: address addressid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN addressid SET DEFAULT nextval('public.address_addressid_seq'::regclass);


--
-- Name: customer customerid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customerid SET DEFAULT nextval('public.customer_customerid_seq'::regclass);


--
-- Name: product productid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN productid SET DEFAULT nextval('public.product_productid_seq'::regclass);


--
-- Name: productcategory productcategoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productcategory ALTER COLUMN productcategoryid SET DEFAULT nextval('public.productcategory_productcategoryid_seq'::regclass);


--
-- Name: productdescription productdescriptionid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productdescription ALTER COLUMN productdescriptionid SET DEFAULT nextval('public.productdescription_productdescriptionid_seq'::regclass);


--
-- Name: productmodel productmodelid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productmodel ALTER COLUMN productmodelid SET DEFAULT nextval('public.productmodel_productmodelid_seq'::regclass);


--
-- Name: salesorderdetail salesorderdetailid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderdetail ALTER COLUMN salesorderdetailid SET DEFAULT nextval('public.salesorderdetail_salesorderdetailid_seq'::regclass);


--
-- Name: salesorderheader salesorderid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderheader ALTER COLUMN salesorderid SET DEFAULT nextval('public.salesorderheader_salesorderid_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (addressid, addressline1, addressline2, city, stateprovince, countryregion, postalcode, rowguid, modifieddate) FROM stdin;
\.
COPY public.address (addressid, addressline1, addressline2, city, stateprovince, countryregion, postalcode, rowguid, modifieddate) FROM '$$PATH$$/3023.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customerid, namestyle, title, firstname, middlename, lastname, suffix, companyname, salesperson, emailaddress, phone, passwordhash, passwordsalt, rowguid, modifieddate) FROM stdin;
\.
COPY public.customer (customerid, namestyle, title, firstname, middlename, lastname, suffix, companyname, salesperson, emailaddress, phone, passwordhash, passwordsalt, rowguid, modifieddate) FROM '$$PATH$$/3025.dat';

--
-- Data for Name: customeraddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customeraddress (customerid, addressid, addresstype, rowguid, modifieddate) FROM stdin;
\.
COPY public.customeraddress (customerid, addressid, addresstype, rowguid, modifieddate) FROM '$$PATH$$/3026.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (productid, name, productnumber, color, standardcost, listprice, size, weight, productcategoryid, productmodelid, sellstartdate, sellenddate, discontinueddate, thumbnailphoto, thumbnailphotofilename, rowguid, modifieddate) FROM stdin;
\.
COPY public.product (productid, name, productnumber, color, standardcost, listprice, size, weight, productcategoryid, productmodelid, sellstartdate, sellenddate, discontinueddate, thumbnailphoto, thumbnailphotofilename, rowguid, modifieddate) FROM '$$PATH$$/3028.dat';

--
-- Data for Name: productcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productcategory (productcategoryid, parentproductcategoryid, name, rowguid, modifieddate) FROM stdin;
\.
COPY public.productcategory (productcategoryid, parentproductcategoryid, name, rowguid, modifieddate) FROM '$$PATH$$/3030.dat';

--
-- Data for Name: productdescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productdescription (productdescriptionid, description, rowguid, modifieddate) FROM stdin;
\.
COPY public.productdescription (productdescriptionid, description, rowguid, modifieddate) FROM '$$PATH$$/3032.dat';

--
-- Data for Name: productmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productmodel (productmodelid, name, catalogdescription, rowguid, modifieddate) FROM stdin;
\.
COPY public.productmodel (productmodelid, name, catalogdescription, rowguid, modifieddate) FROM '$$PATH$$/3034.dat';

--
-- Data for Name: productmodelproductdescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productmodelproductdescription (productmodelid, productdescriptionid, culture, rowguid, modifieddate) FROM stdin;
\.
COPY public.productmodelproductdescription (productmodelid, productdescriptionid, culture, rowguid, modifieddate) FROM '$$PATH$$/3035.dat';

--
-- Data for Name: salesorderdetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salesorderdetail (salesorderid, salesorderdetailid, orderqty, productid, unitprice, unitpricediscount, linetotal, rowguid, modifieddate) FROM stdin;
\.
COPY public.salesorderdetail (salesorderid, salesorderdetailid, orderqty, productid, unitprice, unitpricediscount, linetotal, rowguid, modifieddate) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: salesorderheader; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salesorderheader (salesorderid, revisionnumber, orderdate, duedate, shipdate, status, onlineorderflag, salesordernumber, purchaseordernumber, accountnumber, customerid, shiptoaddressid, billtoaddressid, shipmethod, creditcardapprovalcode, subtotal, taxamt, freight, totaldue, comment, rowguid, modifieddate) FROM stdin;
\.
COPY public.salesorderheader (salesorderid, revisionnumber, orderdate, duedate, shipdate, status, onlineorderflag, salesordernumber, purchaseordernumber, accountnumber, customerid, shiptoaddressid, billtoaddressid, shipmethod, creditcardapprovalcode, subtotal, taxamt, freight, totaldue, comment, rowguid, modifieddate) FROM '$$PATH$$/3039.dat';

--
-- Name: address_addressid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_addressid_seq', 11383, true);


--
-- Name: customer_customerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customerid_seq', 30119, true);


--
-- Name: product_productid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_productid_seq', 1000, true);


--
-- Name: productcategory_productcategoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productcategory_productcategoryid_seq', 42, true);


--
-- Name: productdescription_productdescriptionid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productdescription_productdescriptionid_seq', 2011, true);


--
-- Name: productmodel_productmodelid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productmodel_productmodelid_seq', 129, true);


--
-- Name: salesorderdetail_salesorderdetailid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salesorderdetail_salesorderdetailid_seq', 113407, true);


--
-- Name: salesorderheader_salesorderid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salesorderheader_salesorderid_seq', 71947, true);


--
-- Name: address pk_address_addressid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT pk_address_addressid PRIMARY KEY (addressid);


--
-- Name: customer pk_customer_customerid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT pk_customer_customerid PRIMARY KEY (customerid);


--
-- Name: customeraddress pk_customeraddress_customerid_addressid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customeraddress
    ADD CONSTRAINT pk_customeraddress_customerid_addressid PRIMARY KEY (customerid, addressid);


--
-- Name: product pk_product_productid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT pk_product_productid PRIMARY KEY (productid);


--
-- Name: productcategory pk_productcategory_productcategoryid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productcategory
    ADD CONSTRAINT pk_productcategory_productcategoryid PRIMARY KEY (productcategoryid);


--
-- Name: productdescription pk_productdescription_productdescriptionid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productdescription
    ADD CONSTRAINT pk_productdescription_productdescriptionid PRIMARY KEY (productdescriptionid);


--
-- Name: productmodel pk_productmodel_productmodelid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productmodel
    ADD CONSTRAINT pk_productmodel_productmodelid PRIMARY KEY (productmodelid);


--
-- Name: productmodelproductdescription pk_productmodelproductdescription_productmodelid_productdescri; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productmodelproductdescription
    ADD CONSTRAINT pk_productmodelproductdescription_productmodelid_productdescri PRIMARY KEY (productmodelid, productdescriptionid, culture);


--
-- Name: salesorderdetail pk_salesorderdetail_salesorderid_salesorderdetailid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderdetail
    ADD CONSTRAINT pk_salesorderdetail_salesorderid_salesorderdetailid PRIMARY KEY (salesorderid, salesorderdetailid);


--
-- Name: salesorderheader pk_salesorderheader_salesorderid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderheader
    ADD CONSTRAINT pk_salesorderheader_salesorderid PRIMARY KEY (salesorderid);


--
-- Name: ak_address_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_address_rowguid ON public.address USING btree (rowguid);


--
-- Name: ak_customer_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_customer_rowguid ON public.customer USING btree (rowguid);


--
-- Name: ak_customeraddress_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_customeraddress_rowguid ON public.customeraddress USING btree (rowguid);


--
-- Name: ak_product_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_product_name ON public.product USING btree (name);


--
-- Name: ak_product_productnumber; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_product_productnumber ON public.product USING btree (productnumber);


--
-- Name: ak_product_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_product_rowguid ON public.product USING btree (rowguid);


--
-- Name: ak_productcategory_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productcategory_name ON public.productcategory USING btree (name);


--
-- Name: ak_productcategory_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productcategory_rowguid ON public.productcategory USING btree (rowguid);


--
-- Name: ak_productdescription_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productdescription_rowguid ON public.productdescription USING btree (rowguid);


--
-- Name: ak_productmodel_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productmodel_name ON public.productmodel USING btree (name);


--
-- Name: ak_productmodel_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productmodel_rowguid ON public.productmodel USING btree (rowguid);


--
-- Name: ak_productmodelproductdescription_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_productmodelproductdescription_rowguid ON public.productmodelproductdescription USING btree (rowguid);


--
-- Name: ak_salesorderdetail_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_salesorderdetail_rowguid ON public.salesorderdetail USING btree (rowguid);


--
-- Name: ak_salesorderheader_rowguid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_salesorderheader_rowguid ON public.salesorderheader USING btree (rowguid);


--
-- Name: ak_salesorderheader_salesordernumber; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ak_salesorderheader_salesordernumber ON public.salesorderheader USING btree (salesordernumber);


--
-- Name: ix_address_addressline1_addressline2_city_stateprovince_postal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_address_addressline1_addressline2_city_stateprovince_postal ON public.address USING btree (addressline1, addressline2, city, stateprovince, postalcode, countryregion);


--
-- Name: ix_address_stateprovince; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_address_stateprovince ON public.address USING btree (stateprovince);


--
-- Name: ix_customer_emailaddress; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_customer_emailaddress ON public.customer USING btree (emailaddress);


--
-- Name: ix_salesorderdetail_productid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_salesorderdetail_productid ON public.salesorderdetail USING btree (productid);


--
-- Name: ix_salesorderheader_customerid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_salesorderheader_customerid ON public.salesorderheader USING btree (customerid);


--
-- Name: customeraddress fk_customeraddress_address_addressid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customeraddress
    ADD CONSTRAINT fk_customeraddress_address_addressid FOREIGN KEY (addressid) REFERENCES public.address(addressid);


--
-- Name: customeraddress fk_customeraddress_customer_customerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customeraddress
    ADD CONSTRAINT fk_customeraddress_customer_customerid FOREIGN KEY (customerid) REFERENCES public.customer(customerid);


--
-- Name: product fk_product_productcategory_productcategoryid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fk_product_productcategory_productcategoryid FOREIGN KEY (productcategoryid) REFERENCES public.productcategory(productcategoryid);


--
-- Name: product fk_product_productmodel_productmodelid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fk_product_productmodel_productmodelid FOREIGN KEY (productmodelid) REFERENCES public.productmodel(productmodelid);


--
-- Name: productcategory fk_productcategory_productcategory_parentproductcategoryid_prod; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productcategory
    ADD CONSTRAINT fk_productcategory_productcategory_parentproductcategoryid_prod FOREIGN KEY (parentproductcategoryid) REFERENCES public.productcategory(productcategoryid);


--
-- Name: productmodelproductdescription fk_productmodelproductdescription_productdescription_productdes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productmodelproductdescription
    ADD CONSTRAINT fk_productmodelproductdescription_productdescription_productdes FOREIGN KEY (productdescriptionid) REFERENCES public.productdescription(productdescriptionid);


--
-- Name: productmodelproductdescription fk_productmodelproductdescription_productmodel_productmodelid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productmodelproductdescription
    ADD CONSTRAINT fk_productmodelproductdescription_productmodel_productmodelid FOREIGN KEY (productmodelid) REFERENCES public.productmodel(productmodelid);


--
-- Name: salesorderdetail fk_salesorderdetail_product_productid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderdetail
    ADD CONSTRAINT fk_salesorderdetail_product_productid FOREIGN KEY (productid) REFERENCES public.product(productid);


--
-- Name: salesorderdetail fk_salesorderdetail_salesorderheader_salesorderid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderdetail
    ADD CONSTRAINT fk_salesorderdetail_salesorderheader_salesorderid FOREIGN KEY (salesorderid) REFERENCES public.salesorderheader(salesorderid) ON DELETE CASCADE;


--
-- Name: salesorderheader fk_salesorderheader_address_billto_addressid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderheader
    ADD CONSTRAINT fk_salesorderheader_address_billto_addressid FOREIGN KEY (billtoaddressid) REFERENCES public.address(addressid);


--
-- Name: salesorderheader fk_salesorderheader_address_shipto_addressid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderheader
    ADD CONSTRAINT fk_salesorderheader_address_shipto_addressid FOREIGN KEY (shiptoaddressid) REFERENCES public.address(addressid);


--
-- Name: salesorderheader fk_salesorderheader_customer_customerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesorderheader
    ADD CONSTRAINT fk_salesorderheader_customer_customerid FOREIGN KEY (customerid) REFERENCES public.customer(customerid);


--
-- PostgreSQL database dump complete
--

